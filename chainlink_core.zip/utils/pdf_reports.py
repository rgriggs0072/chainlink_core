﻿# ------------ pdf_reports.py --------------------------------------
# # -*- coding: utf-8 -*-
"""
utils/pdf_reports.py

PDF Report Builders for Chainlink Core
--------------------------------------

Overview:
- Central place for all PDF generators used in Chainlink Core.

Public functions:
- build_predictive_purchases_pdf(...)
    -> Predictive Purchases summary (tenant-wide, by UPC + PRODUCT_ID)

- build_predictive_truck_pdf(...)
    -> Predictive Truck Plan (landscape, per-salesperson pages)

- build_gap_streaks_pdf(...)
    -> Gap streaks by salesperson/store/item, with streak-based coloring
       and a narrow STREAK_WEEKS column so the table fits nicely.

Notes:
- Uses ReportLab when available. If ReportLab is missing, each builder
  returns a simple text payload instead of crashing the app.
- Color palette is aligned with the Chainlink theme:
    PRIMARY_HEX      = "#6497D6"
    NEUTRAL_BG_HEX   = "#F8F2EB"
"""

from __future__ import annotations

from datetime import datetime
from io import BytesIO
from typing import Optional

import pandas as pd

# -------------------------------------------------------------------
# Soft dependency: ReportLab
# -------------------------------------------------------------------
try:
    from reportlab.lib.pagesizes import letter, landscape
    from reportlab.pdfgen import canvas
    from reportlab.lib import colors
    from reportlab.lib.units import inch
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.platypus import (
        SimpleDocTemplate,
        Table,
        TableStyle,
        Paragraph,
        Spacer,
        PageBreak,
    )
    from reportlab.lib.enums import TA_LEFT, TA_CENTER

    _HAS_REPORTLAB = True
except Exception:  # pragma: no cover
    # Fallback stubs so imports don't explode if ReportLab isn't installed.
    _HAS_REPORTLAB = False
    letter = landscape = None
    colors = None
    inch = 72  # arbitrary default
    canvas = None
    SimpleDocTemplate = Table = TableStyle = Paragraph = Spacer = PageBreak = None
    getSampleStyleSheet = ParagraphStyle = None

# -------------------------------------------------------------------
# Chainlink Palette (keep in sync with app theme)
# -------------------------------------------------------------------
PRIMARY_HEX = "#6497D6"  # Primary
NEUTRAL_BG_HEX = "#F8F2EB"  # Background / neutral

if _HAS_REPORTLAB:
    PRIMARY = colors.HexColor(PRIMARY_HEX)
    NEUTRAL_BG = colors.HexColor(NEUTRAL_BG_HEX)


# ===================================================================
# Helper: ASCII-safe text and numeric formatting
# ===================================================================

def _ascii_safe(val) -> str:
    """
    Convert arbitrary value to a simple ASCII-safe string.
    Replaces common Windows-1252 glyphs with plain equivalents.
    """
    s = str(val if val is not None else "")
    replacements = {
        "\u2013": "-",   # en dash
        "\u2014": "-",   # em dash
        "\u2018": "'",   # left single quote
        "\u2019": "'",   # right single quote
        "\u201C": '"',   # left double quote
        "\u201D": '"',   # right double quote
        "\u2026": "...", # ellipsis
        "\xa0": " ",     # non-breaking space
    }
    for k, v in replacements.items():
        s = s.replace(k, v)

    try:
        s.encode("ascii", "strict")
        return s
    except UnicodeEncodeError:
        return s.encode("ascii", "ignore").decode("ascii")


def _fmt_num(x) -> str:
    """Format numeric value with two decimals."""
    try:
        return f"{float(x):,.2f}"
    except Exception:
        return "0.00"


def _fmt_currency(x) -> str:
    """Format currency with dollar sign and two decimals."""
    try:
        return f"${float(x):,.2f}"
    except Exception:
        return "$0.00"


def _x_left() -> float:
    """Left margin helper for canvas-based PDFs."""
    return 0.5 * inch



# ===================================================================
# Shared constants (keep column contracts centralized)
# ===================================================================

# NOTE:
# - This column list is the canonical "Gap History PDF input contract".
# - Any page/email code that builds the "gap streaks" PDF should slice using this list.
# - build_gap_streaks_pdf() will still defensively create ADDRESS if missing,
#   but upstream should always try to supply it.
GAP_HISTORY_PDF_COLUMNS = [
    "CHAIN_NAME",
    "STORE_NUMBER",
    "STORE_NAME",
    "ADDRESS",
    "SUPPLIER_NAME",
    "PRODUCT_NAME",
    "UPC",
    "GAP_FLAG",
    "STREAK_WEEKS",
    "FIRST_GAP_WEEK",
    "LAST_GAP_WEEK",
]



# ===================================================================
# Predictive Purchases PDF
# ===================================================================

def build_predictive_purchases_pdf(
    tenant_name: str,
    horizon_weeks: int,
    summary_table: pd.DataFrame,
    *,
    title: str = "Chainlink - Predictive Purchases",
    rows_per_page: int = 36,
) -> bytes:
    """
    Render a lightweight, branded PDF with header band, title, and a table
    of predictive purchase recommendations.

    Args:
        tenant_name: Tenant display name (shown in header).
        horizon_weeks: Forecast horizon (e.g., 4).
        summary_table: DataFrame with columns:
            ["UPC", "PRODUCT_ID", "Forecast_Units_Next_Period", "Forecast_Revenue_Next_Period"]
        title: Document title for the header band.
        rows_per_page: Max table rows per page (excluding header row).

    Returns:
        bytes: PDF bytes (suitable for st.download_button).
    """
    if not _HAS_REPORTLAB:
        text = (
            f"{title}\n"
            f"Tenant: {tenant_name}\n"
            f"Horizon: {horizon_weeks} week(s)\n\n"
            "Install 'reportlab' to enable full PDF rendering."
        )
        return text.encode("utf-8")

    buf = BytesIO()
    c = canvas.Canvas(buf, pagesize=letter)
    page_w, page_h = letter

    # --- Header band ---
    _draw_header_band(c, page_w, page_h, title, tenant_name, horizon_weeks)

    # --- Section title ---
    y = page_h - 1.15 * inch
    c.setFillColor(colors.black)
    c.setFont("Helvetica-Bold", 12)
    c.drawString(
        _x_left(),
        y,
        "Recommendations (tenant-wide, by UPC + Product ID)",
    )
    y -= 0.24 * inch

    # --- Table header ---
    headers = ["UPC", "PRODUCT_ID", "Forecast Units (next period)", "Forecast Revenue"]
    col_widths = [1.8 * inch, 1.8 * inch, 2.1 * inch, 1.8 * inch]
    y = _draw_table_header(c, y, headers, col_widths)

    # --- Table rows with pagination ---
    if summary_table is not None and len(summary_table) > 0:
        rows_on_page = 0
        c.setFont("Helvetica", 10)

        for _, row in summary_table.iterrows():
            vals = [
                _ascii_safe(row.get("UPC", "")),
                _ascii_safe(row.get("PRODUCT_ID", "")),
                _fmt_num(row.get("Forecast_Units_Next_Period", 0.0)),
                _fmt_currency(row.get("Forecast_Revenue_Next_Period", 0.0)),
            ]

            # New page if needed
            if rows_on_page >= rows_per_page or y < 1.0 * inch:
                c.showPage()
                _draw_header_band(
                    c,
                    page_w,
                    page_h,
                    f"{title} (continued)",
                    tenant_name,
                    horizon_weeks,
                )
                y = page_h - 0.95 * inch
                y = _draw_table_header(c, y, headers, col_widths)
                c.setFont("Helvetica", 10)
                rows_on_page = 0

            # Draw row
            x = _x_left()
            for i, val in enumerate(vals):
                c.drawString(x, y, val)
                x += col_widths[i]
            y -= 0.18 * inch
            rows_on_page += 1
    else:
        c.setFont("Helvetica-Oblique", 10)
        c.drawString(_x_left(), y, "No recommendations available.")
        y -= 0.18 * inch

    # --- Footer ---
    _draw_footer(c, page_w)

    c.save()
    buf.seek(0)
    return buf.getvalue()


def _draw_header_band(c, page_w: float, page_h: float, title: str, tenant_name: str, horizon_weeks: int) -> None:
    """Render the top header band with title and metadata."""
    c.setFillColor(PRIMARY)
    c.rect(0, page_h - 0.8 * inch, page_w, 0.8 * inch, stroke=0, fill=1)

    c.setFillColor(colors.white)
    c.setFont("Helvetica-Bold", 16)
    c.drawString(_x_left(), page_h - 0.5 * inch, _ascii_safe(title))

    c.setFont("Helvetica", 10)
    right_text = f"Tenant: {tenant_name} | Horizon: {horizon_weeks}w"
    c.drawRightString(page_w - _x_left(), page_h - 0.5 * inch, _ascii_safe(right_text))


def _draw_table_header(c, y: float, headers: list[str], col_widths: list[float]) -> float:
    """Draw table header row and underline; return next y."""
    c.setFont("Helvetica-Bold", 10)
    x = _x_left()
    for i, col in enumerate(headers):
        c.drawString(x, y, _ascii_safe(col))
        x += col_widths[i]
    y -= 0.15 * inch
    c.line(_x_left(), y, _x_left() + sum(col_widths), y)
    return y - 0.10 * inch


def _draw_footer(c, page_w: float) -> None:
    """Render a light, unobtrusive footer for canvas-based PDFs."""
    c.setFont("Helvetica", 8)
    c.setFillColor(colors.grey)
    c.drawRightString(
        page_w - _x_left(),
        0.5 * inch,
        _ascii_safe("Generated by Chainlink Core • © 2025 Chainlink Analytics LLC"),
    )


# ===================================================================
# Predictive Truck Plan PDF
# ===================================================================

def build_predictive_truck_pdf(
    week_start,
    horizon_weeks,
    summary_df: pd.DataFrame | None,
    detail_df: pd.DataFrame | None,
    *,
    tenant_name: str | None = None,
    tenant_id: str | None = None,
    run_id: str | None = None,
) -> bytes:
    """
    Predictive Truck Plan PDF (branded, landscape).

    - Cover: tenant, week_start (Monday), horizon, run_id
    - Summary table: salesperson totals
    - Detail: per-salesperson tables with:
        Store #, Chain, Store, UPC, Product Name, Pred (lo–hi).
    """
    effective_tenant = tenant_name or tenant_id or "N/A"

    if not _HAS_REPORTLAB:
        txt = (
            "Predictive Truck Plan\n"
            f"Tenant: {effective_tenant}\n"
            f"Week start (Mon): {week_start}\n"
            f"Horizon (weeks): {horizon_weeks}\n"
            f"RUN_ID: {run_id or 'preview'}\n"
            "Install 'reportlab' for full PDF rendering."
        )
        return txt.encode("utf-8")

    buf = BytesIO()

    # Colors: reuse Chainlink palette if present
    primary = PRIMARY if _HAS_REPORTLAB else colors.HexColor("#6497D6")

    # LANDSCAPE LETTER
    doc = SimpleDocTemplate(
        buf,
        pagesize=landscape(letter),
        leftMargin=36,
        rightMargin=36,
        topMargin=36,
        bottomMargin=36,
    )
    styles = getSampleStyleSheet()
    h1, h2, h3, body = (

        styles["Heading1"],
        styles["Heading2"],
        styles["Heading3"],
        styles["BodyText"],
    )
    small = ParagraphStyle("Small", parent=body, fontSize=9, leading=11)

    # Helper: dataframe → ReportLab table
    def _df_to_table(df: pd.DataFrame, col_widths=None, numeric_cols=None):
        data = [list(df.columns)]
        for _, row in df.iterrows():
            row_cells = []
            for col, val in row.items():
                if isinstance(val, (int, float)) and numeric_cols and col in numeric_cols:
                    row_cells.append(val)
                elif col in ("Product Name",):
                    row_cells.append(Paragraph(str(val or ""), small))
                else:
                    row_cells.append(str(val) if val is not None else "")
            data.append(row_cells)

        t = Table(data, colWidths=col_widths) if col_widths else Table(data)
        t.setStyle(
            TableStyle(
                [
                    ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                    ("FONTSIZE", (0, 0), (-1, -1), 8),
                    ("ALIGN", (0, 0), (-1, 0), "CENTER"),
                    ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                    ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#F0F0F0")),
                    (
                        "ROWBACKGROUNDS",
                        (0, 1),
                        (-1, -1),
                        [colors.white, colors.HexColor("#FBFBFB")],
                    ),
                    ("GRID", (0, 0), (-1, -1), 0.25, colors.HexColor("#DDDDDD")),
                    ("LEFTPADDING", (0, 0), (-1, -1), 3),
                    ("RIGHTPADDING", (0, 0), (-1, -1), 3),
                    ("TOPPADDING", (0, 0), (-1, -1), 2),
                    ("BOTTOMPADDING", (0, 0), (-1, -1), 2),
                ]
            )
        )
        if numeric_cols:
            for idx, col in enumerate(df.columns):
                if col in numeric_cols:
                    t.setStyle(
                        TableStyle(
                            [("ALIGN", (idx, 1), (idx, -1), "RIGHT")]
                        )
                    )
        return t

    story = []

    # Cover
    story.append(Paragraph("Predictive Truck Plan", h1))
    for line in [
        f"Tenant: <b>{effective_tenant}</b>",
        f"Week start (Monday): <b>{week_start}</b>",
        f"Horizon (weeks): <b>{horizon_weeks}</b>",
        f"Run ID: <b>{run_id or 'preview'}</b>",
    ]:
        story.append(Paragraph(line, body))
    story.append(Spacer(1, 12))

    # Summary
    story.append(Paragraph("Summary by Salesperson", h2))
    if summary_df is None or summary_df.empty:
        story.append(Paragraph("No summary rows.", body))
    else:
        view = (
            summary_df[["SALESPERSON", "TOTAL_CASES", "STORES", "SKUS"]]
            .rename(
                columns={
                    "SALESPERSON": "Salesperson",
                    "TOTAL_CASES": "Total Cases",
                    "STORES": "Stores",
                    "SKUS": "SKUs",
                }
            )
        )
        tbl = _df_to_table(
            view,
            col_widths=[160, 100, 80, 60],
            numeric_cols=["Total Cases", "Stores", "SKUs"],
        )
        story.append(tbl)
    story.append(Spacer(1, 18))

    # Detail
    story.append(Paragraph("Detail (Store → UPC)", h2))
    if detail_df is None or detail_df.empty:
        story.append(Paragraph("No detail rows to display.", body))
    else:
        df = detail_df.copy()
        df["PRED_CASES"] = df["PRED_CASES"].astype(float).round(2)
        df["PRED_CASES_LO"] = df["PRED_CASES_LO"].astype(float).round(2)
        df["PRED_CASES_HI"] = df["PRED_CASES_HI"].astype(float).round(2)

        sort_cols = [
            "SALESPERSON",
            "CHAIN_NAME",
            "STORE_NAME",
            "STORE_NUMBER",
            "UPC",
        ]
        existing = [c for c in sort_cols if c in df.columns]
        if existing:
            df = df.sort_values(existing)

        for sp, g in df.groupby("SALESPERSON", dropna=False):
            story.append(Paragraph(f"Salesperson: {sp}", h3))
            story.append(
                Paragraph(
                    "Columns: Store #, Chain, Store, UPC, Product Name, Pred (lo–hi)",
                    small,
                )
            )
            story.append(Spacer(1, 6))

            if "PRODUCT_NAME" not in g.columns:
                g = g.copy()
                g["PRODUCT_NAME"] = ""

            view = g[
                [
                    "STORE_NUMBER",
                    "CHAIN_NAME",
                    "STORE_NAME",
                    "UPC",
                    "PRODUCT_NAME",
                    "PRED_CASES",
                    "PRED_CASES_LO",
                    "PRED_CASES_HI",
                ]
            ].rename(
                columns={
                    "STORE_NUMBER": "Store #",
                    "CHAIN_NAME": "Chain",
                    "STORE_NAME": "Store",
                    "UPC": "UPC",
                    "PRODUCT_NAME": "Product Name",
                    "PRED_CASES": "Pred",
                    "PRED_CASES_LO": "Lo",
                    "PRED_CASES_HI": "Hi",
                }
            )

            rows_per_table = 30
            for i in range(0, len(view), rows_per_table):
                chunk = view.iloc[i : i + rows_per_table]
                story.append(
                    _df_to_table(
                        chunk,
                        col_widths=[50, 70, 90, 80, 220, 55, 45, 45],

                        numeric_cols=["Pred", "Lo", "Hi"],
                    )
                )
                story.append(Spacer(1, 10))

            story.append(PageBreak())

    # Footer per page
    def _on_page(canvas_, doc_):
        canvas_.saveState()
        canvas_.setFillColor(primary)
        canvas_.rect(36, 36, doc_.width, 2, stroke=0, fill=1)
        canvas_.setFillColor(colors.grey)
        canvas_.setFont("Helvetica", 8)
        canvas_.drawRightString(
            doc_.width + 36,
            24,
            "Generated by Chainlink Core • © 2025 Chainlink Analytics LLC",
        )
        canvas_.restoreState()

    doc.build(story, onFirstPage=_on_page, onLaterPages=_on_page)
    pdf = buf.getvalue()
    buf.close()
    return pdf


# ===================================================================
# Gap Streaks PDF (streak colors + narrow STREAK_WEEKS col)
# ===================================================================

def build_gap_streaks_pdf(
    df: pd.DataFrame,
    tenant_name: str = "Client",
    salesperson_name: Optional[str] = None,
    as_of_date: Optional[datetime] = None,
    execution_df: Optional[pd.DataFrame] = None,  # ✅ NEW
) -> bytes:
    """
    Build a Gap Streaks PDF with a compact landscape table.

    Header:
      - Tenant + salesperson name
      - As-of date

    NEW:
      - Weekly Execution Focus summary table (single row) shown ABOVE detail table
        when execution_df is provided.

    Detail table columns:
      Store#, Store, Address, Supplier, Product, Wks

    Color coding by streak length:
      2 weeks  -> soft yellow
      3 weeks  -> soft orange
      4+ weeks -> soft red
    """
    if not _HAS_REPORTLAB:
        txt = f"Gap Streaks Report – {tenant_name}\nInstall 'reportlab' for full PDF rendering."
        return txt.encode("utf-8")

    if as_of_date is None:
        as_of_date = datetime.today()

    df_display = df.copy()

    # Normalize Address casing
    if "ADDRESS" not in df_display.columns:
        for alt in ("Address", "address"):
            if alt in df_display.columns:
                df_display = df_display.rename(columns={alt: "ADDRESS"})
                break

    if "ADDRESS" not in df_display.columns:
        df_display["ADDRESS"] = ""

    # Make streak numeric + safe
    if "STREAK_WEEKS" in df_display.columns:
        df_display["STREAK_WEEKS"] = (
            pd.to_numeric(df_display["STREAK_WEEKS"], errors="coerce")
            .fillna(0)
            .astype(int)
        )
    else:
        df_display["STREAK_WEEKS"] = 0

    # Sort: longest streaks first
    sort_cols = [c for c in ["STREAK_WEEKS", "CHAIN_NAME", "STORE_NUMBER", "PRODUCT_NAME"] if c in df_display.columns]
    if sort_cols:
        asc = [False, True, True, True][: len(sort_cols)]
        df_display = df_display.sort_values(sort_cols, ascending=asc)

    # Detail table columns (NO salesperson)
    cols = [
        "STORE_NUMBER",
        "STORE_NAME",
        "ADDRESS",
        "SUPPLIER_NAME",
        "PRODUCT_NAME",
        "GAP_FLAG",
        "STREAK_WEEKS",
    ]
    cols = [c for c in cols if c in df_display.columns]

    header_labels_map = {
        "STORE_NUMBER": "Store#",
        "STORE_NAME": "Store",
        "ADDRESS": "Address",
        "SUPPLIER_NAME": "Supplier",
        "PRODUCT_NAME": "Product",
        "GAP_FLAG": "Flag",
        "STREAK_WEEKS": "Wks",
    }

    # -----------------------------
    # PDF layout
    # -----------------------------
    buf = BytesIO()
    doc = SimpleDocTemplate(
        buf,
        pagesize=landscape(letter),
        leftMargin=30,
        rightMargin=30,
        topMargin=40,
        bottomMargin=30,
    )

    styles = getSampleStyleSheet()

    # Title style
    title_style = styles["Heading2"].clone("gap_streaks_title")
    title_style.textColor = colors.HexColor("#6497D6")
    title_style.spaceAfter = 6

    # Subtitle + legend
    sub_style = styles["Normal"].clone("gap_streaks_subtitle")
    sub_style.fontSize = 10
    sub_style.leading = 12
    sub_style.spaceAfter = 6

    legend_style = styles["Normal"].clone("gap_streaks_legend")
    legend_style.fontSize = 10
    legend_style.leading = 12
    legend_style.spaceAfter = 10

    # Table cell styles
    cell_style = ParagraphStyle(
        "gap_cell",
        parent=styles["Normal"],
        fontName="Helvetica",
        fontSize=7,
        leading=9,
        alignment=TA_LEFT,
        wordWrap="CJK",
        spaceBefore=0,
        spaceAfter=0,
    )
    cell_style_center = ParagraphStyle(
        "gap_cell_center",
        parent=cell_style,
        alignment=TA_CENTER,
    )
    header_style = ParagraphStyle(
        "gap_header",
        parent=styles["Normal"],
        fontName="Helvetica-Bold",
        fontSize=8,
        leading=10,
        alignment=TA_CENTER,
        textColor=colors.white,
        spaceBefore=0,
        spaceAfter=0,
    )

    def _clean_text(x) -> str:
        """Collapse whitespace + strip to keep ReportLab from exploding row heights."""
        if x is None:
            return ""
        s = str(x)
        s = s.replace("\n", " ").replace("\r", " ").replace("\t", " ")
        s = " ".join(s.split())
        return s

    def _truncate(s: str, n: int) -> str:
        s = _clean_text(s)
        if len(s) <= n:
            return s
        return s[: max(0, n - 1)] + "…"

    def _cell(val, is_center=False, max_len=60):
        txt = _truncate(val, max_len)
        style = cell_style_center if is_center else cell_style

        return Paragraph(txt, style)

    # -----------------------------
    # Weekly Execution Focus table (NEW)
    # -----------------------------
    def _execution_focus_table(exe: Optional[pd.DataFrame]) -> Optional[Table]:
        """
        Build the small Weekly Execution Focus table.
        Returns a ReportLab Table or None if no data.

        IMPORTANT:
        - Must be defined INSIDE build_gap_streaks_pdf() so salesperson_name is in scope.
        """
        if exe is None or exe.empty:
            return None

        r = exe.iloc[0].to_dict()

        salesman = str(r.get("SALESMAN") or salesperson_name or "")
        in_sch = int(r.get("IN_SCHEMATIC") or 0)
        fulfilled = int(r.get("FULFILLED") or 0)
        gaps = int(r.get("GAPS") or 0)
        placement_90 = float(r.get("PLACEMENT_NEEDED_FOR_90") or 0)
        pct_exec = int(r.get("PCT_EXECUTION") or 0)
        gaps_away = float(r.get("GAPS_AWAY_FROM_90") or 0)

        data = [
            [
                "SALESMAN",
                "IN SCHEMATIC",
                "FULFILLED",
                "GAPS",
                "PLACEMENT NEEDED FOR 90%",
                "% EXECUTION",
                "GAPS AWAY FROM 90%",
            ],
            [
                salesman,
                f"{in_sch}",
                f"{fulfilled}",
                f"{gaps}",
                f"{placement_90:,.1f}",
                f"{pct_exec}%",
                f"{gaps_away:,.1f}",
            ],
        ]

        t = Table(data, hAlign="LEFT")
        t.setStyle(
            TableStyle(
                [
                    ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#F8F2EB")),
                    ("TEXTCOLOR", (0, 0), (-1, 0), colors.black),
                    ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                    ("FONTSIZE", (0, 0), (-1, 0), 8),
                    ("FONTSIZE", (0, 1), (-1, 1), 8),
                    ("ALIGN", (1, 0), (-1, -1), "RIGHT"),
                    ("ALIGN", (0, 0), (0, -1), "LEFT"),
                    ("GRID", (0, 0), (-1, -1), 0.5, colors.lightgrey),
                    ("LEFTPADDING", (0, 0), (-1, -1), 6),
                    ("RIGHTPADDING", (0, 0), (-1, -1), 6),
                    ("TOPPADDING", (0, 0), (-1, -1), 4),
                    ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
                ]
            )
        )
        return t



    # -----------------------------
    # Build detail table data
    # -----------------------------
    header_row = [Paragraph(header_labels_map.get(c, c), header_style) for c in cols]
    data = [header_row]

    for _, row in df_display.iterrows():
        r = []
        for c in cols:
            if c == "STREAK_WEEKS":
                r.append(_cell(row.get(c, ""), is_center=True, max_len=6))
            elif c in ("STORE_NUMBER",):
                r.append(_cell(row.get(c, ""), is_center=True, max_len=10))
            elif c == "STORE_NAME":
                r.append(_cell(row.get(c, ""), max_len=22))
            elif c == "ADDRESS":
                r.append(_cell(row.get(c, ""), max_len=34))
            elif c == "SUPPLIER_NAME":
                r.append(_cell(row.get(c, ""), max_len=22))
            elif c == "PRODUCT_NAME":
                r.append(_cell(row.get(c, ""), max_len=44))
            else:
                r.append(_cell(row.get(c, ""), max_len=40))
        data.append(r)

    # Column widths tuned for landscape
    # (fits your labels and keeps PRODUCT readable)
    col_widths_map = {
        "STORE_NUMBER": 55,
        "STORE_NAME": 110,
        "ADDRESS": 160,
        "SUPPLIER_NAME": 110,
        "PRODUCT_NAME": 240,
        "STREAK_WEEKS": 40,
    }
    detail_widths = [col_widths_map.get(c, 90) for c in cols]

    table = Table(data, colWidths=detail_widths, repeatRows=1)

    # Styles + streak color rules
    tbl_style = [
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#6497D6")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("GRID", (0, 0), (-1, -1), 0.35, colors.HexColor("#d5dbe5")),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING", (0, 0), (-1, -1), 4),
        ("RIGHTPADDING", (0, 0), (-1, -1), 4),
        ("TOPPADDING", (0, 0), (-1, -1), 2),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 2),
    ]

    # find streak column index
    streak_idx = cols.index("STREAK_WEEKS") if "STREAK_WEEKS" in cols else None

    # apply row backgrounds based on streak
    if streak_idx is not None:
        for i in range(1, len(data)):  # skip header row 0
            try:
                w = int(df_display.iloc[i - 1]["STREAK_WEEKS"])
            except Exception:
                w = 0

            if w >= 4:
                bg = colors.HexColor("#f8d7da")  # soft red
            elif w == 3:
                bg = colors.HexColor("#ffe5c2")  # soft orange
            elif w == 2:
                bg = colors.HexColor("#fff3cd")  # soft yellow
            else:
                bg = None

            if bg is not None:
                tbl_style.append(("BACKGROUND", (0, i), (-1, i), bg))

    table.setStyle(TableStyle(tbl_style))

    # -----------------------------
    # Story
    # -----------------------------
    title = "Gap History – Weekly Focus"
    story = [
        Paragraph(title, title_style),
        Paragraph(
            f"{tenant_name}"
            + (f" • {salesperson_name}" if salesperson_name else "")
            + f" • As of {as_of_date:%Y-%m-%d}",
            sub_style,
        ),
    ]

    exec_table = _execution_focus_table(execution_df)

    if exec_table is not None:
        story.append(exec_table)
        story.append(Spacer(1, 10))
        story.append(
            Paragraph(
                "<b>We need to get to 90% execution here.</b> Please focus on filling the gaps with products in stock. "
                "Reach out to your manager if you need support. Thank you!",
                legend_style,
            )
        )

    story.append(
        Paragraph(
            "Streak color key: 2 weeks = yellow • 3 weeks = orange • 4+ weeks = red",
            legend_style,
        )
    )
    story.append(table)

    doc.build(story)
    pdf_bytes = buf.getvalue()
    buf.close()
    return pdf_bytes

